package com.ramaqq.storyapp_submission1.pojo

data class UserModel(
    val userId: String,
    val userName: String,
    val token: String,
    val isLogin: Boolean
)
