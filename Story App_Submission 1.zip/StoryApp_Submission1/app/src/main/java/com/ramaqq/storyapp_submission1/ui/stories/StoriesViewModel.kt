package com.ramaqq.storyapp_submission1.ui.stories

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.ramaqq.storyapp_submission1.api.ApiClient
import com.ramaqq.storyapp_submission1.pojo.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class StoriesViewModel : ViewModel() {
    private lateinit var pref: UserPreference
    private val isLoading = MutableLiveData<Boolean>()
    private val isError = MutableLiveData<Boolean>()
    private val data = MutableLiveData<List<ListStoryItem>>()

    fun init(pref: UserPreference) {
        this.pref = pref
        stories()
    }

    private fun stories() {
        isLoading.value = true
        var token: String? = null
        viewModelScope.launch {
            pref.getUser().collect {
                token = it.token

                val client = ApiClient.getApiService().getAllStories("Bearer $token", null)
                client.enqueue(object : Callback<StoriesResponse?> {
                    override fun onResponse(call: Call<StoriesResponse?>, response: Response<StoriesResponse?>) {
                        if (response.isSuccessful && response.body() != null) {
                            isLoading.value = false
                            isError.value = false
                            data.postValue(response.body()?.listStory)
                        }
                    }

                    override fun onFailure(call: Call<StoriesResponse?>, t: Throwable) {
                        isLoading.value = false
                        isError.value = true
                    }
                })
            }
        }
    }

    // test code
    private fun stories_() {
        isLoading.value = true
        val token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiJ1c2VyLWphSGU2Z3JSZFhfSVhnRlQiLCJpYXQiOjE2NjY3NzUyOTN9.HFkqDW5DSP8OUopGFIEULQZJOAUU_iz2i_xP3coWPGY"
                val client = ApiClient.getApiService().getAllStories("Bearer $token", null)
                client.enqueue(object : Callback<StoriesResponse?> {
                    override fun onResponse(call: Call<StoriesResponse?>, response: Response<StoriesResponse?>) {
                        isError.value = false
                        if (response.isSuccessful && response.body() != null) {
                            isLoading.value = false
                            data.postValue(response.body()?.listStory)
                        }
                    }

                    override fun onFailure(call: Call<StoriesResponse?>, t: Throwable) {
                        isLoading.value = false
                        isError.value = true
                    }
                })


    }


    val getStories: LiveData<List<ListStoryItem>> = data
    val getLoading: LiveData<Boolean> = isLoading
    val getError: LiveData<Boolean> = isError
}